const os = require('os');
const settings = require('../settings.js');
const { delay } = require('@whiskeysockets/baileys');

function formatTime(seconds) {
    const days = Math.floor(seconds / (24 * 60 * 60));
    seconds = seconds % (24 * 60 * 60);
    const hours = Math.floor(seconds / (60 * 60));
    seconds = seconds % (60 * 60);
    const minutes = Math.floor(seconds / 60);
    seconds = Math.floor(seconds % 60);

    let time = '';
    if (days > 0) time += `${days}d `;
    if (hours > 0) time += `${hours}h `;
    if (minutes > 0) time += `${minutes}m `;
    if (seconds > 0 || time === '') time += `${seconds}s`;

    return time.trim();
}

function formatBytes(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

async function pingCommand(sock, chatId, message) {
    try {
        const start = Date.now();

        // Send "Calculating..." message first
        const calculatingMsg = await sock.sendMessage(chatId, { 
            text: '```Calculating...```',
            quoted: message
        });

        // Measure time after sending
        const ping = Date.now() - start;

        // Get system info
        const uptimeInSeconds = process.uptime();
        const uptimeFormatted = formatTime(uptimeInSeconds);
        const platform = os.platform();
        const totalMem = formatBytes(os.totalmem());
        const freeMem = formatBytes(os.freemem());
        const usedMem = formatBytes(os.totalmem() - os.freemem());
        const cpuModel = os.cpus()[0].model;

        // Send the bot status
        const botInfo = `
*╭══ 𝟒𝐑𝐄𝐀𝐋 𝐗𝐌𝐃 Status*
*├❃* *Response Time:* ${ping}ms
*├❃* *Platform:* ${platform}
*├❃* *Uptime:* ${uptimeFormatted}
*├❃* *RAM Usage:* ${usedMem} / ${totalMem}
*├❃* *CPU:* ${cpuModel}
*├❃* *Version:* v${settings.version}
*┕──────────────❒*

*>ᴘᴏᴡᴇʀᴇᴅ ʙʏ ʟɪɢᴀɴɢ ᴛᴇᴄʜs*`.trim();

        await sock.sendMessage(chatId, { 
            text: botInfo,
            quoted: message
        });

        // Optionally delete the "Calculating..." message
        await sock.sendMessage(chatId, { delete: calculatingMsg.key });
        
    } catch (error) {
        console.error('Error in ping command:', error);
        await sock.sendMessage(chatId, { 
            text: '❌ Failed to get bot status.',
            quoted: message
        });
    }
}

module.exports = pingCommand;
