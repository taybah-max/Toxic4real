const settings = {
  packname: '4Real Bot',
  author: '‎',
  botName: "4Real Bot",
  botOwner: 'qut@ybah', // Your name
  ownerNumber: '25546657756', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "This is a bot for managing group commands and automating tasks.",
  version: "10.1",
  updateZipUrl: "https://github.com/taybah-max/Toxic4real/raw/refs/heads/main/4Real-MD-main.zip",
};

module.exports = settings;
